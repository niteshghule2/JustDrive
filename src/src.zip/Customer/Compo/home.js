// import logo from "./logo.svg";
// import "./App.css";
// import { useSelector, useDispatch } from "react-redux";
// import { increment } from "../actions";
import bgvideo from "../assets/images/video.mp4";
import { Link } from "react-router-dom"
// import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';


function Home() {
    // const counter = useSelector((state) => state.counter);

    // const isLogged = useSelector((state) => state.isLogged);
    // const dispatch = useDispatch();
    // const history = useHistory();
    // const clicks = () => {
    //     history.push('/dealer')
    // }

    return (
        <div >
            {/* <!-- ***** Main Banner Area Start ***** --> */}
            <div className="main-banner" id="top">
                <video autoPlay={true} muted={true} loop={true} id="bg-video">
                    <source src={bgvideo} type="video/mp4" />
                </video>

                <div className="video-overlay header-text">
                    <div className="caption">
                        {/* <h6>Lorem ipsum dolor sit amet</h6> */}
                        <h2><em>Rent a car,</em> with JustDrive</h2>

                    </div>
                    <form action="search-results.html" method="post" className="signin-form my-form" hidden>
                        <div className="row book-form">
                            <div className="form-input col-md-4 col-sm-6 mt-3">
                                <label>Check-in Date</label>
                                <input type="date" name="" placeholder="Date" required="" />
                            </div>
                            <div className="form-input col-md-4 col-sm-6 mt-3">
                                <label>Check-out Date</label>
                                <input type="date" name="" placeholder="Date" required="" />
                            </div>
                            <div className="form-input col-md-4 col-sm-6 mt-3">
                                <label>Adults</label>
                                <select className="selectpicker">
                                    <option>01</option>
                                    <option>02</option>
                                    <option>03</option>
                                    <option>04</option>
                                </select>

                            </div>
                            <div className="form-input col-md-4 col-sm-6 mt-3">
                                <label>Children</label>
                                <select className="selectpicker">
                                    <option>01</option>
                                    <option>02</option>
                                    <option>03</option>
                                    <option>04</option>
                                </select>

                            </div>
                            <div className="form-input col-md-4 col-sm-6 mt-3">
                                <label>Price </label>
                                <input type="text" name="" placeholder="Max Price ($)" required />
                            </div>
                            <div className="bottom-btn col-md-4 col-sm-6 mt-3">
                                <label>Check availability </label>
                                <button className="btn btn-style btn-primary w-100 px-2">Check Availability</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            {/* <!-- ***** Main Banner Area End ***** --> */}

            {/* <!-- ***** Offers Starts ***** --> */}
            <section className="section" id="trainers">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 offset-lg-3">
                            <div className="section-heading">
                                <h2>Check our <em>Offers</em></h2>
                                <img src="assets/images/line-dec.png" alt="" />
                                <p>Nunc urna sem, laoreet ut metus id, aliquet consequat magna. Sed viverra ipsum dolor, ultricies fermentum massa consequat eu.</p>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-4">
                            <div className="trainer-item">
                                <div className="image-thumb">
                                    <img src="assets/images/offer-1-720x480.jpg" alt="" />
                                </div>
                                <div className="down-content">
                                    <span>from <sup>$</sup>120 per weekend</span>
                                    <h4>Lorem ipsum dolor sit amet, consectetur</h4>
                                    <p>Vestibulum id est eu felis vulputate hendrerit. Suspendisse dapibus turpis in dui pulvinar imperdiet. Nunc consectetur.</p>
                                    <ul className="social-icons">
                                        <li><a href="#">+ Read More</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="trainer-item">
                                <div className="image-thumb">
                                    <img src="assets/images/offer-2-720x480.jpg" alt="" />
                                </div>
                                <div className="down-content">
                                    <span>from <sup>$</sup>120 per weekend</span>
                                    <h4>Lorem ipsum dolor sit amet, consectetur</h4>
                                    <p>Vestibulum id est eu felis vulputate hendrerit. Suspendisse dapibus turpis in dui pulvinar imperdiet. Nunc consectetur.</p>
                                    <ul className="social-icons">
                                        <li><a href="#">+ Read More</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="trainer-item">
                                <div className="image-thumb">
                                    <img src="assets/images/offer-3-720x480.jpg" alt="" />
                                </div>
                                <div className="down-content">
                                    <span>from <sup>$</sup>120 per weekend</span>
                                    <h4>Lorem ipsum dolor sit amet, consectetur</h4>
                                    <p>Vestibulum id est eu felis vulputate hendrerit. Suspendisse dapibus turpis in dui pulvinar imperdiet. Nunc consectetur.</p>
                                    <ul className="social-icons">
                                        <li><a href="#">+ Read More</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <br />

                    <div className="main-button text-center">
                        <a href="offers.html">View Offers</a>
                    </div>
                </div>
            </section>
            {/* <!-- ***** Offers Ends ***** --> */}
            {/*style="background-image: url(assets/images/about-fullscreen-1-1920x700.jpg)"*/}
            <section className="section section-bg" id="schedule" >
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 offset-lg-3">
                            <div className="section-heading dark-bg">
                                <h2>Read <em>About Us</em></h2>
                                <img src="assets/images/line-dec.png" alt="" />
                                <p>Nunc urna sem, laoreet ut metus id, aliquet consequat magna. Sed viverra ipsum dolor, ultricies fermentum massa consequat eu.</p>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="cta-content text-center">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore deleniti voluptas enim! Provident consectetur id earum ducimus facilis, aspernatur hic, alias, harum rerum velit voluptas, voluptate enim! Eos, sunt, quidem.</p>

                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto nulla quo cum officia laboriosam. Amet tempore, aliquid quia eius commodi, doloremque omnis delectus laudantium dolor reiciendis non nulla! Doloremque maxime quo eum in culpa mollitia similique eius doloribus voluptatem facilis! Voluptatibus, eligendi, illum. Distinctio, non!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* <!-- ***** Testimonials Item Start ***** --> */}
            <section className="section" id="features">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6 offset-lg-3">
                            <div className="section-heading">
                                <h2>Read our <em>Testimonials</em></h2>
                                <img src="assets/images/line-dec.png" alt="waves" />
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem incidunt alias minima tenetur nemo necessitatibus?</p>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <ul className="features-items">
                                <li className="feature-item">
                                    <div className="left-icon">
                                        <img src="assets/images/features-first-icon.png" alt="First One" />
                                    </div>
                                    <div className="right-content">
                                        <h4>John Doe</h4>
                                        <p><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta numquam maxime voluptatibus, impedit sed! Necessitatibus repellendus sed deleniti id et!"</em></p>
                                    </div>
                                </li>
                                <li className="feature-item">
                                    <div className="left-icon">
                                        <img src="assets/images/features-first-icon.png" alt="second one" />
                                    </div>
                                    <div className="right-content">
                                        <h4>John Doe</h4>
                                        <p><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta numquam maxime voluptatibus, impedit sed! Necessitatibus repellendus sed deleniti id et!"</em></p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div className="col-lg-6">
                            <ul className="features-items">
                                <li className="feature-item">
                                    <div className="left-icon">
                                        <img src="assets/images/features-first-icon.png" alt="fourth muscle" />
                                    </div>
                                    <div className="right-content">
                                        <h4>John Doe</h4>
                                        <p><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta numquam maxime voluptatibus, impedit sed! Necessitatibus repellendus sed deleniti id et!"</em></p>
                                    </div>
                                </li>
                                <li className="feature-item">
                                    <div className="left-icon">
                                        <img src="assets/images/features-first-icon.png" alt="training fifth" />
                                    </div>
                                    <div className="right-content">
                                        <h4>John Doe</h4>
                                        <p><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dicta numquam maxime voluptatibus, impedit sed! Necessitatibus repellendus sed deleniti id et!"</em></p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <br />

                    <div className="main-button text-center">
                        <a href="testimonials.html">Read More</a>
                    </div>
                </div>
            </section>
            {/* <!-- ***** Testimonials Item End ***** --> */}

            {/* <!-- ***** Call to Action Start ***** --> */}
            {/*style="background-image: url(assets/images/banner-image-1-1920x500.jpg)"*/}
            <section className="section section-bg" id="call-to-action" >
                <div className="container">
                    <div className="row">
                        <div className="col-lg-10 offset-lg-1">
                            <div className="cta-content">
                                <h2>Send us a <em>message</em></h2>
                                <p>Ut consectetur, metus sit amet aliquet placerat, enim est ultricies ligula, sit amet dapibus odio augue eget libero. Morbi tempus mauris a nisi luctus imperdiet.</p>
                                <div className="main-button">
                                    <Link to="/contact">Contact us</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* <!-- ***** Call to Action End ***** --> */}


        </div>
    );
}

export default Home;
