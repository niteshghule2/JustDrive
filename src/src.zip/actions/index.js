//Actions
export const increment = () => {
  return {
    type: "INCREMENT", //name of action
  };
};

export const decrement = () => {
  return {
    type: "DECREMENT", //name of action
  };
};
